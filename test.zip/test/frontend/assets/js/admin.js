/* =========================================================================
   NCST — Admin portal pages (student management, approvals, audit, settings)
   Also serves the staff "Student Directory" via /dashboard/students.
   ========================================================================= */
(function () {
  "use strict";
  const App = window.App;
  const I = App.ICON;
  const svg = App.svg;

  const Admin = {
    /* ---------------- Students / Directory ---------------- */
    studentsPage() {
      const role = App.role();
      if (role === "STAFF") return Admin.directoryPage();
      App.setPageTitle("Student Management");
      App.content().innerHTML = `
        <div class="page-header">
          <div><h1>Student & User Management</h1><p>Register, edit, archive, and manage institutional accounts.</p></div>
          <div class="page-actions">
            <button class="btn btn-secondary" onclick="Admin.openBulkImport()">${svg(I.upload)} Bulk Import</button>
            <button class="btn btn-primary" onclick="Admin.openAddStudent()">${svg(I.plus)} Add User</button>
          </div>
        </div>
        <div class="card">
          <div class="toolbar">
            <div class="search">${svg(I.search)}<input class="form-control" id="usr-search" placeholder="Search name or ID…"></div>
            <select class="form-control" id="usr-role" style="max-width:150px"><option value="">All roles</option><option value="STUDENT">Student</option><option value="STAFF">Staff</option><option value="FACULTY">Faculty</option></select>
            <select class="form-control" id="usr-status" style="max-width:150px"><option value="">All status</option><option value="ACTIVE">Active</option><option value="ARCHIVED">Archived</option></select>
            <button class="btn btn-primary" onclick="Admin.loadStudents(1)">${svg(I.search)} Filter</button>
          </div>
          <div id="usr-table">${App.loadingBlock("Loading users…")}</div>
          <div id="usr-pager"></div>
        </div>`;
      App.content().querySelector("#usr-search").addEventListener("keydown", (e) => { if (e.key === "Enter") Admin.loadStudents(1); });
      Admin.loadStudents(1);
    },

    directoryPage() {
      App.setPageTitle("Student Directory");
      App.content().innerHTML = `
        <div class="page-header"><div><h1>Student Directory</h1><p>Search and view enrolled students (read-only).</p></div></div>
        <div class="card">
          <div class="toolbar">
            <div class="search">${svg(I.search)}<input class="form-control" id="usr-search" placeholder="Search name or ID…"></div>
            <select class="form-control" id="usr-role" style="max-width:150px"><option value="">All roles</option><option value="STUDENT">Student</option><option value="STAFF">Staff</option><option value="FACULTY">Faculty</option></select>
            <select class="form-control" id="usr-status" style="max-width:150px"><option value="">All status</option><option value="ACTIVE">Active</option><option value="ARCHIVED">Archived</option></select>
            <button class="btn btn-primary" onclick="Admin.loadStudents(1)">${svg(I.search)} Filter</button>
          </div>
          <div id="usr-table">${App.loadingBlock("Loading…")}</div>
          <div id="usr-pager"></div>
        </div>`;
      App.content().querySelector("#usr-search").addEventListener("keydown", (e) => { if (e.key === "Enter") Admin.loadStudents(1); });
      Admin.loadStudents(1);
    },

    async loadStudents(page) {
      Admin._usrPage = page || 1;
      const search = document.getElementById("usr-search")?.value || "";
      const roleFilter = document.getElementById("usr-role")?.value || "";
      const status = document.getElementById("usr-status")?.value || "";
      const wrap = document.getElementById("usr-table");
      const pager = document.getElementById("usr-pager");
      const isStaff = App.role() === "STAFF";
      wrap.innerHTML = App.loadingBlock("Loading…");
      try {
        let list;
        if (isStaff) {
          const params = new URLSearchParams();
          if (search) params.set("search", search);
          if (roleFilter) params.set("role", roleFilter);
          if (status) params.set("status", status);
          const qs = params.toString();
          list = await App.api(`/staff/students${qs ? `?${qs}` : ""}`);
        } else {
          const q = `?page=${page}&page_size=25` + (search ? `&search=${encodeURIComponent(search)}` : "") + (roleFilter ? `&role=${roleFilter}` : "") + (status ? `&status=${status}` : "");
          list = await App.api(`/admin/users${q}`);
        }
        if (!list.length) { wrap.innerHTML = App.emptyState("No users found", "Try adjusting your filters or add a new user.", I.users); pager.innerHTML = ""; return; }
        const isAdmin = App.role() === "ADMIN";
        const body = list.map((u) => `<tr>
          <td class="cell-strong">${App.esc(u.first_name + " " + u.last_name)}</td>
          <td class="cell-sub">${App.esc(u.user_id)}</td>
          <td>${App.badge("muted", u.role)}</td>
          <td>${App.esc(u.department_section || "—")}</td>
          <td>${App.statusBadge(u.status)}</td>
          <td class="text-right" style="text-align:right;white-space:nowrap">
            ${isAdmin ? `<button class="btn btn-ghost btn-sm" title="Edit" onclick="Admin.openEditStudent('${u.user_id}')">${svg(I.edit)}</button>
            <button class="btn btn-ghost btn-sm" title="Re-enroll face" onclick="Admin.openReenroll('${u.user_id}')">${svg(I.camera)}</button>
            <button class="btn btn-ghost btn-sm" title="Reset password" onclick="Admin.openResetPassword('${u.user_id}')">${svg(I.settings)}</button>
            <button class="btn btn-ghost btn-sm ${u.status === "ACTIVE" ? "btn-danger" : "btn-success"}" title="Archive/Restore" onclick="Admin.toggleUser('${u.user_id}')"><svg>${u.status === "ACTIVE" ? I.archive : I.refresh}</svg></button>` : ""}
          </td></tr>`).join("");
        wrap.innerHTML = `<div class="table-wrap"><table class="data"><thead><tr><th>Name</th><th>ID</th><th>Role</th><th>Department</th><th>Status</th><th></th></tr></thead><tbody>${body}</tbody></table></div>`;
        pager.innerHTML = isStaff
          ? `<div class="pagination"><span class="page-info">Showing ${list.length} result${list.length === 1 ? "" : "s"}</span></div>`
          : App.pagination(list.length < 25 ? (page - 1) * 25 + list.length : page * 25 + 1, page, 25, (p) => Admin.loadStudents(p));
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },

    openAddStudent() {
      openUserForm("Add User", null);
    },
    openEditStudent(id) {
      App.api(`/admin/users/${id}`).then((u) => openUserForm("Edit User", u)).catch((e) => App.toast(e.message, "error"));
    },

    async toggleUser(id) {
      try { await App.api(`/admin/users/${id}/status`, { method: "PUT" }); App.toast("Status updated.", "success"); Admin.loadStudents(Admin._usrPage || 1); }
      catch (e) { App.toast(e.message, "error"); }
    },

    openReenroll(id) {
      faceCaptureModal(`Re-enroll Face — ${id}`, async (blob) => {
        const fd = new FormData(); fd.append("image", blob, "face.jpg");
        await App.api(`/admin/users/${id}/re-enroll`, { method: "POST", body: fd });
        App.toast("Face re-enrolled.", "success");
      });
    },

    openResetPassword(id) {
      App.modal({
        title: "Reset User Password",
        body: `<div class="form-group"><label>New Password (min 6 chars)</label><input class="form-control" id="rp-pw" type="text" placeholder="Temporary password"></div>
          <p class="form-hint">The user will be notified. They can change it later.</p>`,
        footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="rp-save">Reset</button>`,
        onOpen: (m) => m.querySelector("#rp-save").addEventListener("click", async () => {
          const pw = m.querySelector("#rp-pw").value.trim();
          try { await App.api(`/admin/users/${id}/reset-password`, { method: "POST", body: JSON.stringify({ new_password: pw }) }); App.toast("Password reset.", "success"); App.closeModal(); }
          catch (e) { App.toast(e.message, "error"); }
        }),
      });
    },

    openBulkImport() {
      App.api("/admin/students/bulk-template").then((tpl) => {
        const csv = [tpl.headers.join(","), tpl.sample.join(",")].join("\n");
        App.modal({
          title: "Bulk Import Students",
          size: "lg",
          body: `<p class="form-hint">Paste CSV rows (header required). Columns: ${tpl.headers.join(", ")}.</p>
            <textarea class="form-control" id="bulk-csv" rows="10" style="font-family:monospace">${csv}</textarea>
            <div class="mt-2"><button class="btn btn-ghost btn-sm" onclick="Admin.downloadTemplate()">${svg(I.download)} Download template</button></div>
            <div id="bulk-msg" class="mt-2"></div>`,
          footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="bulk-import">Import</button>`,
          onOpen: (m) => {
            window.__bulkCsv = csv;
            m.querySelector("#bulk-import").addEventListener("click", async () => {
              const text = m.querySelector("#bulk-csv").value.trim();
              const lines = text.split(/\r?\n/).filter(Boolean);
              const headers = lines[0].split(",").map((h) => h.trim());
              const rows = lines.slice(1).map((l) => {
                const cells = l.split(",");
                const o = {}; headers.forEach((h, i) => (o[h] = (cells[i] || "").trim())); return o;
              });
              try {
                const r = await App.api("/admin/students/bulk-import", { method: "POST", body: JSON.stringify({ rows }) });
                App.toast(r.message, "success"); App.closeModal(); Admin.loadStudents(1);
              } catch (e) { m.querySelector("#bulk-msg").innerHTML = App.alert("error", e.message); }
            });
          },
        });
      }).catch((e) => App.toast(e.message, "error"));
    },

    downloadTemplate() {
      const csv = window.__bulkCsv || "user_id,first_name,last_name,role,department_section\n";
      const blob = new Blob([csv], { type: "text/csv" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "students-template.csv"; a.click();
    },

    /* ---------------- Approvals ---------------- */
    approvalsPage() {
      App.setPageTitle("Approval Center");
      App.content().innerHTML = `
        <div class="page-header"><div><h1>Approval Center</h1><p>Review profile changes, re-registration, and account requests.</p></div>
          <button class="btn btn-secondary" onclick="Admin.loadApprovals()">${svg(I.refresh)} Refresh</button></div>
        <div class="grid grid-2">
          <div class="card"><div class="card-header"><div class="card-title">Approval Requests</div></div><div id="appr-list">${App.loadingBlock()}</div></div>
          <div class="card"><div class="card-header"><div class="card-title">Profile Change Requests</div></div><div id="prof-list">${App.loadingBlock()}</div></div>
        </div>`;
      Admin.loadApprovals();
    },

    async loadApprovals() {
      try {
        const approvals = await App.api("/approvals");
        const prof = App.role() === "ADMIN"
          ? await App.api("/admin/profile-update-requests").catch(() => [])
          : (await App.api("/students/me/requests").catch(() => ({ profile_updates: [] }))).profile_updates || [];
        const aWrap = document.getElementById("appr-list");
        const pWrap = document.getElementById("prof-list");
        if (!approvals.length) aWrap.innerHTML = App.emptyState("Nothing pending", "No approval requests.", I.check);
        else aWrap.innerHTML = `<div class="timeline">` + approvals.map((a) => `
          <div class="timeline-item ${a.status === "APPROVED" ? "success" : a.status === "REJECTED" ? "warning" : ""}">
            <span class="tl-dot"></span>
            <div class="d-flex justify-between align-center"><div><div class="tl-title">${App.esc(a.request_type)}</div><div class="tl-sub">${App.esc(a.user_id)} · ${App.fmtDateTime(a.requested_at)}</div></div>${App.statusBadge(a.status)}</div>
            ${a.details ? `<div class="text-xs text-muted mt-1">${App.esc(a.details)}</div>` : ""}
            ${a.status === "PENDING" ? `<div class="mt-1"><button class="btn btn-success btn-sm" onclick="Admin.decide(${a.id},'APPROVED')">Approve</button> <button class="btn btn-danger btn-sm" onclick="Admin.decide(${a.id},'REJECTED')">Reject</button></div>` : ""}
          </div>`).join("") + `</div>`;
        const pu = prof.profile_updates || [];
        if (!pu.length) pWrap.innerHTML = App.emptyState("Nothing pending", "No profile change requests.", I.user);
        else pWrap.innerHTML = `<div class="timeline">` + pu.map((p) => `
          <div class="timeline-item ${p.status === "APPROVED" ? "success" : p.status === "REJECTED" ? "warning" : ""}">
            <span class="tl-dot"></span>
            <div class="tl-title">${App.esc(p.field_name)}</div>
            <div class="tl-sub">${App.esc(p.user_id)}: ${App.esc(p.old_value || "—")} → <b>${App.esc(p.new_value)}</b></div>
            <div class="text-xs text-muted">${App.fmtDateTime(p.requested_at)} · ${App.statusBadge(p.status)}</div>
          </div>`).join("") + `</div>`;
      } catch (e) { App.toast(e.message, "error"); }
    },

    async decide(id, decision) {
      try { await App.api(`/approvals/${id}/decide`, { method: "POST", body: JSON.stringify({ decision, notes: "" }) }); App.toast(`Request ${decision.toLowerCase()}.`, "success"); Admin.loadApprovals(); }
      catch (e) { App.toast(e.message, "error"); }
    },

    /* ---------------- Audit ---------------- */
    auditPage() {
      App.setPageTitle("Audit Logs");
      App.content().innerHTML = `
        <div class="page-header"><div><h1>Audit Logs</h1><p>Record of administrative actions across the system.</p></div></div>
        <div class="card">
          <div class="toolbar">
            <div class="search">${svg(I.search)}<input class="form-control" id="aud-search" placeholder="Search action or email…"></div>
            <button class="btn btn-primary" onclick="Admin.loadAudit(1)">${svg(I.search)} Filter</button>
          </div>
          <div id="aud-table">${App.loadingBlock("Loading logs…")}</div>
          <div id="aud-pager"></div>
        </div>`;
      Admin.loadAudit(1);
    },

    async loadAudit(page) {
      Admin._audPage = page || 1;
      const search = document.getElementById("aud-search")?.value || "";
      const wrap = document.getElementById("aud-table");
      wrap.innerHTML = App.loadingBlock("Loading…");
      try {
        const q = `?page=${page}&page_size=25` + (search ? `&search=${encodeURIComponent(search)}` : "");
        const d = await App.api(`/admin/audit-logs${q}`);
        if (!d.items.length) { wrap.innerHTML = App.emptyState("No logs", "No audit entries match.", I.audit); document.getElementById("aud-pager").innerHTML = ""; return; }
        const body = d.items.map((r) => `<tr><td class="cell-sub">${App.esc(r.logged_at)}</td><td class="cell-strong">${App.esc(r.action)}</td><td>${App.esc(r.admin_email || "system")}</td><td class="text-muted text-sm">${App.esc(r.details || "")}</td></tr>`).join("");
        wrap.innerHTML = `<div class="table-wrap"><table class="data"><thead><tr><th>Time</th><th>Action</th><th>User</th><th>Details</th></tr></thead><tbody>${body}</tbody></table></div>`;
        document.getElementById("aud-pager").innerHTML = App.pagination(d.total, page, 25, (p) => Admin.loadAudit(p));
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },

    /* ---------------- Settings ---------------- */
    settingsPage() {
      App.setPageTitle("System Settings");
      App.content().innerHTML = `<div id="set-wrap">${App.loadingBlock("Loading settings…")}</div>`;
      Admin.loadSettings();
    },

    async loadSettings() {
      const wrap = document.getElementById("set-wrap");
      try {
        const face = await App.api("/health/face");
        wrap.innerHTML = `
          <div class="grid grid-2">
            <div class="card"><div class="card-header"><div class="card-title">Face Recognition Engine</div></div>
              <div class="mb-2">${face.status === "ok" ? App.badge("success", "Operational") : App.badge("danger", "Error")}</div>
              <div class="text-sm text-muted">Model: <b>${App.esc(face.model)}</b></div>
              <div class="text-sm text-muted">Engine: ${App.esc(face.engine)}</div>
              ${face.error ? `<div class="alert alert-warning mt-2">${App.esc(face.error)}</div>` : ""}
            </div>
            <div class="card"><div class="card-header"><div class="card-title">Change My Password</div></div>
              <div class="form-group"><label>Current Password</label><input class="form-control" id="cp-old" type="password"></div>
              <div class="form-group"><label>New Password</label><input class="form-control" id="cp-new" type="password"></div>
              <button class="btn btn-primary" id="cp-save">Update Password</button>
            </div>
          </div>
          <div class="card mt-3"><div class="card-header"><div class="card-title">System Information</div></div>
            <div class="text-sm text-muted">NCST Face Recognition Attendance System · v1.0.0</div>
            <div class="text-sm text-muted">Security: password hashing (bcrypt), JWT sessions, rate limiting, parameterized queries.</div>
          </div>`;
        wrap.querySelector("#cp-save").addEventListener("click", async () => {
          const oldp = wrap.querySelector("#cp-old").value, newp = wrap.querySelector("#cp-new").value;
          try { await App.api("/auth/change-password", { method: "POST", body: JSON.stringify({ old_password: oldp, new_password: newp }) }); App.toast("Password updated.", "success"); wrap.querySelector("#cp-old").value = ""; wrap.querySelector("#cp-new").value = ""; }
          catch (e) { App.toast(e.message, "error"); }
        });
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },
  };

  /* ---------------- Shared form helpers ---------------- */
  function openUserForm(title, user) {
    const u = user || {};
    App.modal({
      title,
      size: "lg",
      body: `
        <div class="form-row cols-2">
          <div class="form-group"><label>User ID *</label><input class="form-control" id="uf-id" value="${App.esc(u.user_id || "")}" ${u.user_id ? "disabled" : ""}></div>
          <div class="form-group"><label>Role *</label><select class="form-control" id="uf-role"><option value="STUDENT" ${u.role === "STUDENT" ? "selected" : ""}>Student</option><option value="STAFF" ${u.role === "STAFF" ? "selected" : ""}>Staff</option><option value="FACULTY" ${u.role === "FACULTY" ? "selected" : ""}>Faculty</option></select></div>
        </div>
        <div class="form-row cols-2">
          <div class="form-group"><label>First Name *</label><input class="form-control" id="uf-fn" value="${App.esc(u.first_name || "")}"></div>
          <div class="form-group"><label>Last Name *</label><input class="form-control" id="uf-ln" value="${App.esc(u.last_name || "")}"></div>
        </div>
        <div class="form-group"><label>Department / Section *</label><input class="form-control" id="uf-dep" value="${App.esc(u.department_section || "")}" placeholder="e.g. BSCS-3A"></div>
        ${u.user_id ? "" : `<div class="form-row cols-2"><div class="form-group"><label>Email</label><input class="form-control" id="uf-email" placeholder="user@ncst.edu"></div><div class="form-group"><label>Password</label><input class="form-control" id="uf-pw" placeholder="min 6 chars"></div></div>`}
        <div class="form-row cols-3"><div class="form-group"><label>Course</label><input class="form-control" id="uf-course" value="${App.esc(u.course || "")}"></div><div class="form-group"><label>Year Level</label><input class="form-control" id="uf-year" value="${App.esc(u.year_level || "")}"></div><div class="form-group"><label>Section</label><input class="form-control" id="uf-sec" value="${App.esc(u.section || "")}"></div></div>
        <div class="form-row cols-2"><div class="form-group"><label>Contact Number</label><input class="form-control" id="uf-contact" value="${App.esc(u.contact_number || "")}"></div><div class="form-group"><label>Emergency Contact</label><input class="form-control" id="uf-emerg" value="${App.esc(u.emergency_contact || "")}"></div></div>
        ${u.user_id ? "" : `<div class="form-group"><label>Face Image *</label><div id="uf-cam-wrap"></div></div>`}
        <div id="uf-msg" class="mt-1"></div>`,
      footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="uf-save">${u.user_id ? "Save Changes" : "Register User"}</button>`,
      onOpen: (m) => {
        if (!u.user_id) setupFaceCapture(m.querySelector("#uf-cam-wrap"));
        m.querySelector("#uf-save").addEventListener("click", async () => {
          const payload = {
            first_name: m.querySelector("#uf-fn").value.trim(),
            last_name: m.querySelector("#uf-ln").value.trim(),
            role: m.querySelector("#uf-role").value,
            department_section: m.querySelector("#uf-dep").value.trim(),
            course: m.querySelector("#uf-course").value.trim(),
            year_level: m.querySelector("#uf-year").value.trim(),
            section: m.querySelector("#uf-sec").value.trim(),
            contact_number: m.querySelector("#uf-contact").value.trim(),
            emergency_contact: m.querySelector("#uf-emerg").value.trim(),
          };
          if (!payload.first_name || !payload.last_name || !payload.department_section) { m.querySelector("#uf-msg").innerHTML = App.alert("warning", "Name, role, and department are required."); return; }
          const saveBtn = m.querySelector("#uf-save"); saveBtn.disabled = true; saveBtn.innerHTML = App.spinner() + " Saving…";
          try {
            if (u.user_id) {
              await App.api(`/admin/users/${u.user_id}`, { method: "PUT", body: JSON.stringify(payload) });
              App.toast("User updated.", "success");
            } else {
              const fd = new FormData();
              fd.append("user_id", m.querySelector("#uf-id").value.trim());
              fd.append("first_name", payload.first_name);
              fd.append("last_name", payload.last_name);
              fd.append("role", payload.role);
              fd.append("department_section", payload.department_section);
              fd.append("course", payload.course); fd.append("year_level", payload.year_level); fd.append("section", payload.section);
              fd.append("contact_number", payload.contact_number); fd.append("emergency_contact", payload.emergency_contact);
              const email = m.querySelector("#uf-email").value.trim(); if (email) fd.append("email", email);
              const pw = m.querySelector("#uf-pw").value; if (pw) fd.append("password", pw);
              if (!window.__captureBlob) { m.querySelector("#uf-msg").innerHTML = App.alert("warning", "Please capture a face image."); saveBtn.disabled = false; saveBtn.textContent = "Register User"; return; }
              fd.append("image", window.__captureBlob, "face.jpg");
              await App.api("/register", { method: "POST", body: fd });
              App.toast("User registered.", "success");
            }
            App.closeModal(); Admin.loadStudents(Admin._usrPage || 1);
          } catch (e) { m.querySelector("#uf-msg").innerHTML = App.alert("error", e.message); saveBtn.disabled = false; saveBtn.textContent = u.user_id ? "Save Changes" : "Register User"; }
        });
      },
    });
  }

  function setupFaceCapture(wrap) {
    wrap.innerHTML = `<video id="uf-video" autoplay playsinline muted style="width:100%;border-radius:12px;background:#000;display:none"></video>
      <div class="empty-state" id="uf-prev">Camera off</div>
      <div class="toolbar mt-2"><button class="btn btn-secondary" id="uf-start">Start Camera</button><button class="btn btn-primary" id="uf-cap" disabled>Capture</button></div>`;
    const video = wrap.querySelector("#uf-video");
    const prev = wrap.querySelector("#uf-prev");
    wrap.querySelector("#uf-start").addEventListener("click", async () => {
      try { await App.startCamera(video); video.style.display = "block"; prev.style.display = "none"; wrap.querySelector("#uf-cap").disabled = false; }
      catch (e) { prev.innerHTML = App.alert("error", "Camera access denied."); }
    });
    wrap.querySelector("#uf-cap").addEventListener("click", async () => {
      window.__captureBlob = await App.captureFrame(video);
      App.stopCamera();
      prev.style.display = "block"; prev.innerHTML = `<div class="alert alert-success">Face captured ✓</div>`;
      video.style.display = "none";
    });
  }

  function faceCaptureModal(title, onCapture) {
    App.modal({
      title, size: "lg",
      body: `<video id="fc-video" autoplay playsinline muted style="width:100%;border-radius:12px;background:#000;display:none"></video>
        <div class="empty-state" id="fc-prev">Camera off</div>
        <div class="toolbar mt-2"><button class="btn btn-secondary" id="fc-start">Start Camera</button><button class="btn btn-primary" id="fc-cap" disabled>Capture</button></div>
        <div id="fc-msg"></div>`,
      onOpen: (m) => {
        const video = m.querySelector("#fc-video"); const prev = m.querySelector("#fc-prev");
        m.querySelector("#fc-start").addEventListener("click", async () => {
          try { await App.startCamera(video); video.style.display = "block"; prev.style.display = "none"; m.querySelector("#fc-cap").disabled = false; }
          catch (e) { m.querySelector("#fc-msg").innerHTML = App.alert("error", "Camera access denied."); }
        });
        m.querySelector("#fc-cap").addEventListener("click", async () => {
          const blob = await App.captureFrame(video); App.stopCamera();
          try { await onCapture(blob); App.closeModal(); } catch (e) { m.querySelector("#fc-msg").innerHTML = App.alert("error", e.message); }
        });
      },
    });
  }

  /* ---------------- Routes (admin) ---------------- */
  App.router.add("/dashboard/students", (p) => Admin.studentsPage(p));
  App.router.add("/dashboard/approvals", () => Admin.approvalsPage());
  App.router.add("/dashboard/audit", () => Admin.auditPage());
  App.router.add("/dashboard/settings", () => Admin.settingsPage());

  window.Admin = Admin;
})();
