/* =========================================================================
   NCST — Shared portal pages (overview dispatch, attendance, announcements,
   profile, face, notifications, scanner). Role-aware.
   ========================================================================= */
(function () {
  "use strict";
  const App = window.App;
  const I = App.ICON;
  const svg = App.svg;

  /* ---------------- Overview (role dispatch) ---------------- */
  App.router.add("/dashboard/overview", async function () {
    const role = App.role();
    if (role === "ADMIN") return Shared.adminOverview();
    if (role === "STAFF") return Shared.staffOverview();
    return Shared.studentOverview();
  });

  /* ---------------- Bar chart ---------------- */
  function barChart(series, labelFmt) {
    if (!series || !series.length) return App.emptyState("No data yet", "Attendance activity will appear here as records are captured.", I.calendar);
    const max = Math.max.apply(null, series.map((s) => s.count)) || 1;
    const bars = series.slice(-14).map((s) => {
      const h = Math.max(4, Math.round((s.count / max) * 100));
      const lbl = labelFmt ? labelFmt(s) : String(s.date).slice(5);
      return `<div class="bar-col"><div class="bar" style="height:${h}%" title="${App.esc(s.date)}: ${s.count}"></div><div class="bar-label">${App.esc(lbl)}</div></div>`;
    }).join("");
    return `<div class="bar-chart">${bars}</div>`;
  }

  const Shared = {
    /* ---------------- Attendance ---------------- */
    attendancePage(params) {
      const role = App.role();
      App.setPageTitle(role === "STUDENT" ? "My Attendance" : "Attendance");
      const canManage = role === "ADMIN";
      const canExport = true;
      App.content().innerHTML = `
        <div class="page-header">
          <div><h1>${role === "STUDENT" ? "My Attendance Records" : "Attendance Records"}</h1>
            <p>${role === "STUDENT" ? "Review your time-in and time-out history." : "Monitor and manage attendance across the institution."}</p></div>
          <div class="page-actions">
            ${canExport ? `<button class="btn btn-secondary" onclick="Shared.exportAttendance()">${svg(I.download)} Export CSV</button>` : ""}
            ${canManage ? `<button class="btn btn-secondary" onclick="Shared.refreshAttendance()">${svg(I.refresh)} Refresh</button>` : ""}
          </div>
        </div>
        <div class="card">
          <div class="toolbar">
            <div class="search">${svg(I.search)}<input class="form-control" id="att-search" placeholder="Search name or ID…"></div>
            <input type="date" class="form-control" id="att-from" style="max-width:170px" title="From date">
            <input type="date" class="form-control" id="att-to" style="max-width:170px" title="To date">
            <select class="form-control" id="att-status" style="max-width:160px">
              <option value="">All statuses</option>
              <option value="PRESENT">Present</option>
              <option value="LATE">Late</option>
              <option value="ABSENT">Absent</option>
            </select>
            <button class="btn btn-primary" onclick="Shared.loadAttendance(1)">${svg(I.search)} Filter</button>
          </div>
          <div id="att-table">${App.loadingBlock("Loading attendance…")}</div>
          <div id="att-pager"></div>
        </div>`;
      App.content().querySelector("#att-search").addEventListener("keydown", (e) => { if (e.key === "Enter") Shared.loadAttendance(1); });
      Shared._attPage = 1;
      Shared.loadAttendance(1);
    },

    async loadAttendance(page) {
      Shared._attPage = page || 1;
      const role = App.role();
      const search = document.getElementById("att-search")?.value || "";
      const from = document.getElementById("att-from")?.value || "";
      const to = document.getElementById("att-to")?.value || "";
      const status = document.getElementById("att-status")?.value || "";
      const pageSize = 25;
      const wrap = document.getElementById("att-table");
      const pager = document.getElementById("att-pager");
      wrap.innerHTML = App.loadingBlock("Loading…");
      try {
        let data, endpoint;
        if (role === "STUDENT") {
          endpoint = `/students/me/attendance?page=${page}&page_size=${pageSize}` + (from ? `&date_from=${from}` : "") + (to ? `&date_to=${to}` : "");
          data = await App.api(endpoint);
        } else if (role === "STAFF") {
          endpoint = `/staff/attendance?page=${page}&page_size=${pageSize}` + (search ? `&search=${encodeURIComponent(search)}` : "") + (from ? `&date_from=${from}` : "") + (to ? `&date_to=${to}` : "");
          data = await App.api(endpoint);
        } else {
          endpoint = `/admin/logs?page=${page}&page_size=${pageSize}` + (search ? `&search=${encodeURIComponent(search)}` : "") + (from ? `&date_from=${from}` : "") + (to ? `&date_to=${to}` : "");
          data = await App.api(endpoint);
        }
        const rows = data.items || [];
        if (!rows.length) { wrap.innerHTML = App.emptyState("No attendance records", "No records match the current filters.", I.calendar); pager.innerHTML = ""; return; }
        const head = `<thead><tr>
          <th>Student</th><th>ID</th><th>Role</th><th>Date</th><th>Time In</th><th>Time Out</th><th>Status</th><th>Device</th>
          ${role === "ADMIN" ? "<th></th>" : ""}</tr></thead>`;
        const body = rows.map((r) => `<tr>
          <td class="cell-strong">${App.esc(r.user_name || (r.first_name + " " + r.last_name) || "—")}</td>
          <td class="cell-sub">${App.esc(r.user_id)}</td>
          <td>${App.badge("muted", r.role || "—")}</td>
          <td>${App.esc(r.date || "—")}</td>
          <td>${App.esc(r.time_in || "—")}</td>
          <td>${App.esc(r.time_out || "—")}</td>
          <td>${App.statusBadge(r.attendance_status)}</td>
          <td class="cell-sub">${App.esc(r.device_id || "—")}</td>
          ${role === "ADMIN" ? `<td><button class="btn btn-ghost btn-sm" onclick="Shared.correctAttendance(${r.log_id})">${svg(I.edit)}</button></td>` : ""}
        </tr>`).join("");
        wrap.innerHTML = `<div class="table-wrap"><table class="data">${head}<tbody>${body}</tbody></table></div>`;
        pager.innerHTML = App.pagination(data.total || rows.length, page, pageSize, (p) => Shared.loadAttendance(p));
      } catch (err) {
        wrap.innerHTML = App.alert("error", err.message);
      }
    },

    refreshAttendance() { Shared.loadAttendance(Shared._attPage || 1); },

    exportAttendance() {
      const role = App.role();
      const from = document.getElementById("att-from")?.value || "";
      const to = document.getElementById("att-to")?.value || "";
      if (role === "STUDENT") {
        const q = (from ? `?date_from=${from}` : "") + (to ? (from ? "&" : "?") + `date_to=${to}` : "");
        window.location.href = App.API + "/students/me/attendance/export" + q;
      } else {
        const q = `?report_type=daily${from ? "&date_from=" + from : ""}${to ? "&date_to=" + to : ""}`;
        window.location.href = App.API + "/reports/export" + q;
      }
    },

    correctAttendance(logId) {
      App.modal({
        title: "Correct Attendance Record",
        body: `<div class="form-group"><label>Time Out</label><input class="form-control" id="corr-timeout" placeholder="HH:MM:SS (leave blank to clear)"></div>
               <div class="form-group"><label>Status</label><select class="form-control" id="corr-status"><option value="PRESENT">PRESENT</option><option value="LATE">LATE</option><option value="ABSENT">ABSENT</option></select></div>`,
        footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="corr-save">Save</button>`,
        onOpen: (m) => {
          m.querySelector("#corr-save").addEventListener("click", async () => {
            const timeout = m.querySelector("#corr-timeout").value.trim();
            const status = m.querySelector("#corr-status").value;
            try {
              await App.api(`/admin/logs/${logId}`, { method: "PUT", body: JSON.stringify({ time_out: timeout || null, attendance_status: status }) });
              App.toast("Record updated.", "success"); App.closeModal(); Shared.loadAttendance(Shared._attPage || 1);
            } catch (e) { App.toast(e.message, "error"); }
          });
        },
      });
    },

    /* ---------------- Announcements ---------------- */
    announcementsPage() {
      const role = App.role();
      const isAdmin = role === "ADMIN";
      App.setPageTitle("Announcements");
      App.content().innerHTML = `
        <div class="page-header">
          <div><h1>Announcements</h1><p>Institutional notices and updates.</p></div>
          ${isAdmin ? `<button class="btn btn-primary" onclick="Shared.createAnnouncement()">${svg(I.plus)} New Announcement</button>` : ""}
        </div>
        <div id="ann-list">${App.loadingBlock("Loading announcements…")}</div>`;
      Shared.loadAnnouncements();
    },

    async loadAnnouncements() {
      const wrap = document.getElementById("ann-list");
      try {
        const list = await App.api("/announcements");
        if (!list.length) { wrap.innerHTML = App.emptyState("No announcements", "There are no announcements at this time.", I.megaphone); return; }
        wrap.innerHTML = `<div class="grid grid-2">` + list.map((a) => `
          <div class="card">
            <div class="card-header">
              <div><div class="card-title">${App.esc(a.title)}</div><div class="card-subtitle">${App.esc(a.target_role)} · ${App.fmtDateTime(a.created_at)}</div></div>
              ${a.is_pinned ? App.badge("warning", "Pinned") : ""}
            </div>
            <p class="text-muted" style="white-space:pre-wrap">${App.esc(a.content)}</p>
            ${App.role() === "ADMIN" ? `<div class="mt-2"><button class="btn btn-ghost btn-sm btn-danger" onclick="Shared.deleteAnnouncement(${a.id})">${svg(I.trash)} Delete</button></div>` : ""}
          </div>`).join("") + `</div>`;
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },

    createAnnouncement() {
      App.modal({
        title: "New Announcement",
        body: `<div class="form-group"><label>Title</label><input class="form-control" id="ann-title" placeholder="e.g. Enrollment Schedule"></div>
               <div class="form-group"><label>Message</label><textarea class="form-control" id="ann-content" rows="4" placeholder="Write the announcement…"></textarea></div>
               <div class="form-row cols-2"><div class="form-group"><label>Audience</label><select class="form-control" id="ann-target"><option value="ALL">Everyone</option><option value="STUDENT">Students</option><option value="STAFF">Staff</option></select></div>
               <div class="form-group"><label><input type="checkbox" id="ann-pinned"> Pin to top</label></div></div>`,
        footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="ann-save">Publish</button>`,
        onOpen: (m) => {
          m.querySelector("#ann-save").addEventListener("click", async () => {
            const title = m.querySelector("#ann-title").value.trim();
            const content = m.querySelector("#ann-content").value.trim();
            if (!title || !content) { App.toast("Title and message are required.", "warning"); return; }
            try {
              await App.api("/announcements", { method: "POST", body: JSON.stringify({ title, content, target_role: m.querySelector("#ann-target").value, is_pinned: m.querySelector("#ann-pinned").checked }) });
              App.toast("Announcement published.", "success"); App.closeModal(); Shared.loadAnnouncements();
            } catch (e) { App.toast(e.message, "error"); }
          });
        },
      });
    },

    async deleteAnnouncement(id) {
      App.confirm("Delete Announcement", "This announcement will be permanently removed.", async () => {
        try { await App.api(`/announcements/${id}`, { method: "DELETE" }); App.toast("Deleted.", "success"); Shared.loadAnnouncements(); }
        catch (e) { App.toast(e.message, "error"); }
      }, true);
    },

    /* ---------------- Profile (student / staff) ---------------- */
    profilePage() {
      const role = App.role();
      App.setPageTitle("My Profile");
      App.content().innerHTML = `<div id="profile-wrap">${App.loadingBlock("Loading profile…")}</div>`;
      Shared.loadProfile();
    },

    async loadProfile() {
      const wrap = document.getElementById("profile-wrap");
      try {
        const isStudent = App.role() === "STUDENT";
        const p = isStudent ? await App.api("/students/me") : await App.api("/staff/me");
        const face = isStudent ? await App.api("/students/me/face") : null;
        const rows = [
          ["Student / Staff Number", p.user_id],
          ["Full Name", `${p.first_name} ${p.last_name}`],
          ["Email", p.email || "—"],
          ["Program / Department", p.department_section || "—"],
          ["Role", p.role],
          ["Contact", p.contact_number || "—"],
          ["Address", p.address || "—"],
          ["Emergency Contact", p.emergency_contact || "—"],
        ];
        if (isStudent) {
          rows.splice(4, 0, ["Course", p.course || "—"], ["Year Level", p.year_level || "—"], ["Section", p.section || "—"]);
        }
        const grid = rows.map(([k, v]) => `<div class="form-group" style="margin:0"><label>${App.esc(k)}</label><div class="text-sm fw-600">${App.esc(v)}</div></div>`).join("");
        wrap.innerHTML = `
          <div class="page-header"><div><h1>My Profile</h1><p>Your personal and contact information.</p></div>
            <button class="btn btn-primary" onclick="Shared.requestProfileUpdate()">${svg(I.edit)} Request Update</button></div>
          <div class="grid grid-2">
            <div class="card"><div class="card-header"><div class="card-title">Account Details</div></div><div class="form-row">${grid}</div></div>
            ${isStudent ? `<div class="card"><div class="card-header"><div class="card-title">Face Registration</div></div>
              <div class="mb-2">${face && face.status === "REGISTERED" ? App.badge("success", "Registered") : App.badge("warning", "Not Registered")}</div>
              <button class="btn btn-secondary w-full" onclick="Shared.openFaceUpload()">${svg(I.upload)} Update Face</button>
              <button class="btn btn-ghost w-full mt-1" onclick="Shared.requestFaceReregister()">${svg(I.refresh)} Request Re-registration</button>
              <div class="mt-2"><a href="#/dashboard/face">View face profile →</a></div>
            </div>` : ""}
          </div>`;
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },

    requestProfileUpdate() {
      App.modal({
        title: "Request Profile Changes",
        body: `<p class="form-hint">Changes are applied only after administrator approval.</p>
          <div id="pu-fields"></div>
          <button class="btn btn-secondary btn-sm mt-1" type="button" onclick="Shared.addProfileField()">${svg(I.plus)} Add field</button>`,
        footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="pu-save">Submit Request</button>`,
        onOpen: (m) => {
          Shared.addProfileField();
          m.querySelector("#pu-save").addEventListener("click", async () => {
            const rows = m.querySelectorAll(".pu-row");
            let submitted = 0;
            for (const row of rows) {
              const field = row.querySelector(".pu-field").value;
              const val = row.querySelector(".pu-value").value.trim();
              if (!val) continue;
              try { await App.api("/students/me", { method: "PUT", body: JSON.stringify({ [field]: val }) }); submitted++; }
              catch (e) { App.toast(e.message, "error"); }
            }
            if (submitted) { App.toast(`${submitted} change request(s) submitted.`, "success"); App.closeModal(); }
            else App.toast("Enter at least one value.", "warning");
          });
        },
      });
    },

    addProfileField() {
      const fields = [["first_name", "First Name"], ["last_name", "Last Name"], ["email", "Email"], ["contact_number", "Contact Number"], ["address", "Address"], ["emergency_contact", "Emergency Contact"], ["course", "Course"], ["year_level", "Year Level"], ["section", "Section"]];
      const wrap = document.getElementById("pu-fields");
      if (!wrap) return;
      const row = document.createElement("div");
      row.className = "pu-row form-row cols-2 mb-1";
      row.innerHTML = `<select class="form-control pu-field">${fields.map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select>
        <input class="form-control pu-value" placeholder="New value">`;
      wrap.appendChild(row);
    },

    openFaceUpload() {
      App.modal({
        title: "Update Face Image",
        body: `<p class="form-hint">Capture a clear, front-facing photo with good lighting.</p>
          <video id="face-video" autoplay playsinline muted style="width:100%;border-radius:12px;background:#000;display:none"></video>
          <div id="face-preview" class="empty-state">Camera off</div>
          <div class="toolbar mt-2"><button class="btn btn-secondary" id="face-start">Start Camera</button>
          <button class="btn btn-primary" id="face-capture" disabled>Capture & Save</button></div>
          <div id="face-msg"></div>`,
        size: "lg",
        onOpen: (m) => {
          const video = m.querySelector("#face-video");
          const preview = m.querySelector("#face-preview");
          const start = m.querySelector("#face-start");
          const cap = m.querySelector("#face-capture");
          let blob = null;
          start.addEventListener("click", async () => {
            try { await App.startCamera(video); video.style.display = "block"; preview.style.display = "none"; cap.disabled = false; }
            catch (e) { m.querySelector("#face-msg").innerHTML = App.alert("error", "Camera access denied."); }
          });
          cap.addEventListener("click", async () => {
            blob = await App.captureFrame(video);
            cap.disabled = true; cap.innerHTML = App.spinner() + " Saving…";
            const fd = new FormData(); fd.append("image", blob, "face.jpg");
            try {
              await App.api("/students/me/face", { method: "POST", body: fd });
              App.toast("Face updated.", "success"); App.stopCamera(); App.closeModal();
            } catch (e) { App.toast(e.message, "error"); cap.disabled = false; cap.textContent = "Capture & Save"; }
          });
        },
      });
    },

    async requestFaceReregister() {
      try { await App.api("/students/me/face-reregister-request", { method: "POST" }); App.toast("Re-registration requested.", "success"); }
      catch (e) { App.toast(e.message, "error"); }
    },

    /* ---------------- Face (student) ---------------- */
    facePage() {
      App.setPageTitle("Face Profile");
      App.content().innerHTML = `<div id="face-wrap">${App.loadingBlock("Loading…")}</div>`;
      Shared.loadFaceProfile();
    },

    async loadFaceProfile() {
      const wrap = document.getElementById("face-wrap");
      try {
        const face = await App.api("/students/me/face");
        const reqs = await App.api("/students/me/requests");
        const registered = face.status === "REGISTERED";
        const approvals = (reqs.approvals || []).filter((a) => a.request_type === "FACE_REREGISTER");
        wrap.innerHTML = `
          <div class="page-header"><div><h1>Face Profile</h1><p>Manage your biometric enrollment and re-registration requests.</p></div>
            <button class="btn btn-secondary" onclick="Shared.openFaceUpload()">${svg(I.upload)} Update Face</button></div>
          <div class="grid grid-2">
            <div class="card"><div class="card-header"><div class="card-title">Enrollment Status</div></div>
              <div class="d-flex align-center gap-2">${registered ? App.badge("success", "Registered") : App.badge("warning", "Not Registered")}</div>
              <p class="text-muted text-sm mt-2">${registered ? "Your face is enrolled and recognized by attendance scanners." : "You are not yet enrolled. Please update your face image."}</p>
            </div>
            <div class="card"><div class="card-header"><div class="card-title">Re-registration Requests</div></div>
              ${approvals.length ? approvals.map((a) => `<div class="timeline-item ${a.status === "APPROVED" ? "success" : a.status === "REJECTED" ? "warning" : ""}"><span class="tl-dot"></span><div class="tl-title">${App.esc(a.request_type)}</div><div class="tl-sub">${App.statusBadge(a.status)} · ${App.fmtDateTime(a.requested_at)}</div></div>`).join("") : App.emptyState("No requests", "Request re-registration if your face is not recognized.", I.face)}
              <button class="btn btn-ghost mt-2" onclick="Shared.requestFaceReregister()">${svg(I.refresh)} Request Re-registration</button>
            </div>
          </div>`;
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },

    /* ---------------- Notifications (student) ---------------- */
    notificationsPage() {
      App.setPageTitle("Notifications");
      App.content().innerHTML = `
        <div class="page-header"><div><h1>Notifications</h1><p>Your alerts and approval updates.</p></div>
          <button class="btn btn-secondary" onclick="Shared.markAllRead()">${svg(I.check)} Mark all read</button></div>
        <div id="notif-list">${App.loadingBlock("Loading…")}</div>`;
      Shared.loadNotifications();
    },

    async loadNotifications() {
      const wrap = document.getElementById("notif-list");
      try {
        const list = await App.api("/students/me/notifications");
        if (!list.length) { wrap.innerHTML = App.emptyState("No notifications", "You're all caught up.", I.bell); return; }
        wrap.innerHTML = `<div class="card" style="padding:0;overflow:hidden">` + list.map((n) => `
          <div class="d-flex gap-2 align-center" style="padding:.9rem 1.1rem;border-bottom:1px solid var(--border);${n.is_read ? "opacity:.6" : ""}">
            <span class="avatar-sm" style="background:${n.notification_type === "APPROVAL" ? "var(--info-50)" : "var(--surface-2)"};color:${n.notification_type === "APPROVAL" ? "var(--info-700)" : "var(--muted)"}">${svg(I.bell, 16)}</span>
            <div class="flex-1"><div class="fw-600">${App.esc(n.title)}</div><div class="text-muted text-sm">${App.esc(n.message)}</div><div class="text-xs text-muted">${App.fmtDateTime(n.created_at)}</div></div>
            ${n.is_read ? "" : `<button class="btn btn-ghost btn-sm" onclick="Shared.markRead(${n.id})">Mark read</button>`}
          </div>`).join("") + `</div>`;
        App.refreshNotifBadge();
      } catch (e) { wrap.innerHTML = App.alert("error", e.message); }
    },

    async markRead(id) { try { await App.api(`/students/me/notifications/${id}/read`, { method: "POST" }); Shared.loadNotifications(); } catch (e) { App.toast(e.message, "error"); } },
    async markAllRead() { try { await App.api("/notifications/mark-all-read", { method: "POST" }); App.toast("All marked read.", "success"); Shared.loadNotifications(); } catch (e) { App.toast(e.message, "error"); } },

    async refreshNotifBadge() {
      try {
        const list = await App.api("/students/me/notifications");
        const unread = list.filter((n) => !n.is_read).length;
        const dot = document.getElementById("notif-dot");
        if (dot) dot.style.display = unread ? "block" : "none";
      } catch (e) {}
    },

    /* ---------------- Scanner embed ---------------- */
    scannerPage() {
      App.setPageTitle("Live Scanner");
      App.content().innerHTML = `
        <div class="page-header"><div><h1>Live Attendance Scanner</h1><p>Full-screen kiosk mode is available for entrance terminals.</p></div>
          <a class="btn btn-secondary" href="/scanner" target="_blank">${svg(I.camera)} Open Kiosk Mode</a></div>
        <iframe class="embed-frame" src="/scanner" title="Scanner"></iframe>`;
    },

    /* ---------------- Overview renderers ---------------- */
    async studentOverview() {
      App.setPageTitle("Student Dashboard");
      App.content().innerHTML = `<div id="ov">${App.loadingBlock("Loading your dashboard…")}</div>`;
      try {
        const d = await App.api("/students/me/dashboard");
        const el = document.getElementById("ov");
        el.innerHTML = `
          <div class="grid grid-4 mb-3">
            ${Shared.statCard("Attendance Rate", d.attendance_rate + "%", "success", I.clock, `Based on ${d.total} records`)}
            ${Shared.statCard("Present", d.present, "success", I.check, "Sessions marked present")}
            ${Shared.statCard("This Week", d.week_count, "primary", I.calendar, "Attendance days this week")}
            ${Shared.statCard("Unread", d.unread_notifications, d.unread_notifications ? "warning" : "muted", I.bell, "Notifications")}
          </div>
          <div class="grid grid-3">
            <div class="chart-card"><div class="card-title mb-2">Last 30 Days</div>${barChart(d.series, (s) => String(s.date).slice(5))}</div>
            <div class="card"><div class="card-header"><div class="card-title">Face & Status</div></div>
              <div class="mb-2">${d.face_status === "REGISTERED" ? App.badge("success", "Face Registered") : App.badge("warning", "Face Not Registered")}</div>
              <div class="text-sm text-muted">Attendance rate: <b>${d.attendance_rate}%</b></div>
              <div class="progress mt-1"><div class="progress-bar ${d.attendance_rate >= 75 ? "success" : d.attendance_rate >= 50 ? "warning" : "danger"}" style="width:${d.attendance_rate}%"></div></div>
            </div>
            <div class="card"><div class="card-header"><div class="card-title">Summary</div></div>
              <div class="timeline">
                <div class="timeline-item"><span class="tl-dot"></span><div class="tl-title">Total Records</div><div class="tl-sub">${d.total}</div></div>
                <div class="timeline-item success"><span class="tl-dot"></span><div class="tl-title">Present</div><div class="tl-sub">${d.present}</div></div>
                <div class="timeline-item warning"><span class="tl-dot"></span><div class="tl-title">Late</div><div class="tl-sub">${d.late}</div></div>
                <div class="timeline-item"><span class="tl-dot"></span><div class="tl-title">This Month</div><div class="tl-sub">${d.month_count}</div></div>
              </div>
            </div>
          </div>
          <div class="card mt-3"><div class="card-header"><div class="card-title">Recent Attendance</div><a href="#/dashboard/attendance">View all →</a></div>
            ${d.recent.length ? `<div class="table-wrap"><table class="data"><thead><tr><th>Name</th><th>Date</th><th>Time In</th><th>Time Out</th><th>Status</th></tr></thead><tbody>` +
              d.recent.map((r) => `<tr><td class="cell-strong">${App.esc(r.user_name)}</td><td>${App.esc(r.date)}</td><td>${App.esc(r.time_in || "—")}</td><td>${App.esc(r.time_out || "—")}</td><td>${App.statusBadge(r.attendance_status)}</td></tr>`).join("") +
              `</tbody></table></div>` : App.emptyState("No recent activity", "Your attendance will appear here.", I.calendar)}
          </div>`;
      } catch (e) { document.getElementById("ov").innerHTML = App.alert("error", e.message); }
    },

    async staffOverview() {
      App.setPageTitle("Staff Dashboard");
      App.content().innerHTML = `<div id="ov">${App.loadingBlock("Loading dashboard…")}</div>`;
      try {
        const d = await App.api("/staff/dashboard/stats");
        document.getElementById("ov").innerHTML = `
          <div class="grid grid-4 mb-3">
            ${Shared.statCard("Attendance Today", d.attendance_today, "primary", I.calendar, "Unique students today")}
            ${Shared.statCard("Total Students", d.total_students, "success", I.users, "Active enrolled")}
            ${Shared.statCard("This Month", d.month_attendance, "warning", I.clock, "Attendance logs")}
            ${Shared.statCard("Announcements", d.announcements, "muted", I.megaphone, "Published")}
          </div>
          <div class="grid grid-3">
            <div class="chart-card" style="grid-column:span 2"><div class="card-title mb-2">Attendance — Last 14 Days</div>${barChart(d.series, (s) => String(s.date).slice(5))}</div>
            <div class="card"><div class="card-header"><div class="card-title">Recent Activity</div></div>
              ${d.recent.length ? `<div class="timeline">` + d.recent.map((r) => `<div class="timeline-item success"><span class="tl-dot"></span><div class="tl-title">${App.esc(r.user_name)}</div><div class="tl-sub">${App.esc(r.date)} · ${App.esc(r.time_in || "")} · ${App.statusBadge(r.attendance_status)}</div></div>`).join("") + `</div>` : App.emptyState("No activity", "No recent attendance.", I.calendar)}
            </div>
          </div>`;
      } catch (e) { document.getElementById("ov").innerHTML = App.alert("error", e.message); }
    },

    async adminOverview() {
      App.setPageTitle("Administrator Dashboard");
      App.content().innerHTML = `<div id="ov">${App.loadingBlock("Loading dashboard…")}</div>`;
      try {
        const d = await App.api("/admin/dashboard/stats");
        const dist = d.role_distribution || [];
        const donut = buildDonut(dist);
        document.getElementById("ov").innerHTML = `
          <div class="grid grid-4 mb-3">
            ${Shared.statCard("Total Students", d.total_students, "primary", I.users, "Active")}
            ${Shared.statCard("Total Staff", d.total_staff, "success", I.users, "Active")}
            ${Shared.statCard("Attendance Today", d.attendance_today, "warning", I.calendar, "Unique students")}
            ${Shared.statCard("Pending Approvals", d.pending_approvals, d.pending_approvals ? "danger" : "muted", I.check, "Awaiting review")}
          </div>
          <div class="grid grid-3">
            <div class="chart-card" style="grid-column:span 2"><div class="card-header"><div class="card-title">Attendance — Last 14 Days</div><span class="text-xs text-muted">Success rate today: ${d.recognition_success_rate}%</span></div>${barChart(d.series, (s) => String(s.date).slice(5))}</div>
            <div class="card"><div class="card-header"><div class="card-title">Population</div></div>${donut}<div class="mt-2 text-xs text-muted">Cameras online: <b>${d.active_cameras}</b> · Model: <b>${d.face_model_status.status}</b></div></div>
          </div>
          <div class="card mt-3"><div class="card-header"><div class="card-title">Recent Attendance</div><a href="#/dashboard/attendance">View all →</a></div>
            ${d.recent.length ? `<div class="table-wrap"><table class="data"><thead><tr><th>Name</th><th>ID</th><th>Date</th><th>Time In</th><th>Status</th><th>Device</th></tr></thead><tbody>` +
              d.recent.map((r) => `<tr><td class="cell-strong">${App.esc(r.user_name)}</td><td class="cell-sub">${App.esc(r.user_id)}</td><td>${App.esc(r.date)}</td><td>${App.esc(r.time_in || "—")}</td><td>${App.statusBadge(r.attendance_status)}</td><td class="cell-sub">${App.esc(r.device_id)}</td></tr>`).join("") +
              `</tbody></table></div>` : App.emptyState("No recent activity", "Attendance records will appear here.", I.calendar)}
          </div>`;
      } catch (e) { document.getElementById("ov").innerHTML = App.alert("error", e.message); }
    },

    statCard(label, value, tone, icon, meta) {
      return `<div class="stat ${tone}"><div class="stat-icon">${svg(icon)}</div>
        <div class="stat-label">${App.esc(label)}</div><div class="stat-value">${App.esc(value)}</div>
        <div class="stat-meta">${App.esc(meta || "")}</div></div>`;
    },
  };

  function buildDonut(dist) {
    if (!dist.length) return App.emptyState("No data", "No active users.", I.users);
    const total = dist.reduce((s, d) => s + d.count, 0) || 1;
    const colors = { STUDENT: "var(--secondary)", STAFF: "var(--success)", FACULTY: "var(--warning)" };
    let acc = 0; const segs = dist.map((d) => {
      const start = (acc / total) * 360; acc += d.count; const end = (acc / total) * 360;
      return `<stop offset="${(start / 360) * 100}%" stop-color="${colors[d.role] || "var(--accent)"}"/><stop offset="${(end / 360) * 100}%" stop-color="${colors[d.role] || "var(--accent)"}"/>`;
    }).join("");
    const legend = dist.map((d) => `<div class="item"><span class="swatch" style="background:${colors[d.role] || "var(--accent)"}"></span>${App.esc(d.role)} — ${d.count}</div>`).join("");
    return `<div class="donut-wrap"><div class="donut" style="background:conic-gradient(${dist.map((d, i) => `${colors[d.role] || "var(--accent)"} ${(i === 0 ? 0 : dist.slice(0, i).reduce((s, x) => s + x.count, 0) / total * 100)}% ${dist.slice(0, i + 1).reduce((s, x) => s + x.count, 0) / total * 100}%`).join(",")})"></div><div class="legend">${legend}</div></div>`;
  }

  /* ---------------- Route registration (shared) ---------------- */
  App.router.add("/dashboard/attendance", (p) => Shared.attendancePage(p));
  App.router.add("/dashboard/announcements", () => Shared.announcementsPage());
  App.router.add("/dashboard/profile", () => Shared.profilePage());
  App.router.add("/dashboard/face", () => Shared.facePage());
  App.router.add("/dashboard/notifications", () => Shared.notificationsPage());
  App.router.add("/dashboard/scanner", () => Shared.scannerPage());
  // /dashboard/students and /dashboard/overview dispatched elsewhere / above.

  window.Shared = Shared;
})();
