# NCST Face Recognition Attendance System

Enterprise-grade academic attendance platform with biometric (face) recognition,
role-based access, a Student Self-Service Portal, an Administrator console, and a
Staff portal — all backed by FastAPI + SQLite.

---

## Features

| Area | Highlights |
|------|-----------|
| **Face Recognition** | InsightFace (`buffalo_sc`) embeddings, cosine-similarity matching, configurable threshold, daily duplicate prevention (time-in / time-out). |
| **Authentication** | JWT sessions, role selection (Admin / Staff / Student), OTP-based admin approval & password recovery, rate limiting. |
| **Student Portal** | Dashboard (attendance rate, weekly/monthly summaries, recent activity), attendance history with filters + CSV export, read-only profile, **approval-gated profile edits**, face status + re-registration requests, notifications. |
| **Admin Console** | Overview analytics, user/student management (add, edit, archive/restore, bulk import, reset password, re-enroll face), attendance administration (filter, correct, export), **Approval Center**, announcements, audit logs, scanner, settings. |
| **Staff Portal** | Attendance monitoring, student directory (read-only), announcements, own profile, scanner status. |
| **Public Scanner** | Full-screen kiosk at `/scanner` with live camera, real-time recognition, confirmation card (name, ID, time, status), clock, and camera-health indicator. |
| **Approval Workflow** | Student changes → `PENDING` → admin `APPROVE/REJECT` → change applied + user notified. Covers profile edits, face re-registration, account & password requests. |
| **Security** | bcrypt password hashing, parameterized queries (no SQLi), per-IP rate limiting, safe CORS, audit logging, soft-delete (archive), session expiry. |

---

## Quick start

```bash
git clone <repo-url>
cd ncst-face-detection-system
cp .env.example .env          # then set a strong JWT_SECRET_KEY
python -m venv venv
venv\Scripts\activate         # or: source venv/bin/activate
pip install -r requirements.txt
python run.py                 # http://localhost:8000
```

Open **http://localhost:8000** → sign in.

### Default administrator
- Email: `paullacuesta732@gmail.com`
- Password: `NCST 2026`

### Gmail / OTP email (optional)
Enable 2-Step Verification and create an App Password, then configure the SMTP credentials in `.env` to send emails via Gmail.

#### Step-by-Step Gmail App Password Setup:
1. Go to your [Google Account Dashboard](https://myaccount.google.com).
2. Navigate to the **Security** tab on the left.
3. Under the **How you sign in to Google** section, ensure **2-Step Verification** is enabled.
4. Click on **2-Step Verification**, scroll to the bottom, and select **App passwords** (if not visible, search for "App passwords" in the Google Account search bar).
5. Enter a name for the app (e.g., `NCST Attendance System`) and click **Create**.
6. Copy the generated 16-character password (e.g., `abcd efgh ijkl mnop`).
7. Paste this code (without spaces) into the `SMTP_PASSWORD` field in your `.env` file.

#### PHPMailer Integration Setup:
The system delegates all emails to a local, self-contained PHP runtime environment inside `php_runtime/` which invokes PHPMailer inside `php_mailer/`. There is no need to configure a local web server (Nginx/Apache) for PHP; the FastAPI server automatically spawns PHP cli tasks in the background when an OTP needs to be sent.

Ensure `.env` contains:
```ini
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-16-character-gmail-app-password
SMTP_FROM_EMAIL=your-email@gmail.com
SMTP_USE_TLS=True
SMTP_USE_SSL=False
```
If SMTP settings are missing or blank, the system falls back to printing OTP codes to the python server console log for local development.

---

## Roles & portals

| Role | Portal entry | Capabilities |
|------|-------------|--------------|
| **Administrator** | `/dashboard/overview` | Full management, approvals, audit, settings. |
| **Staff** | `/dashboard/overview` | Attendance, student directory, announcements, profile. |
| **Student** | `/dashboard/overview` | Own attendance, profile (request edits), face, notifications. |
| **Public Scanner** | `/scanner` | Kiosk attendance capture (no sign-in required). |

---

## API surface (prefix `/api/v1`)

- `POST /auth/login`, `/auth/register`, `/auth/register/request-verification`
- `POST /auth/forgot-password/request-otp`, `/auth/forgot-password/reset`
- `POST /auth/change-password`, `/auth/logout`, `/auth/me`
- `POST /register` (face enrollment), `POST /verify` (attendance)
- `GET /admin/users`, `PUT/POST/DELETE` user management, `/admin/logs`, `/admin/audit-logs`, `/admin/dashboard/stats`
- `GET /staff/attendance`, `/staff/students`, `/staff/dashboard/stats`
- `GET /students/me`, `/students/me/attendance`, `/students/me/dashboard`, `/students/me/face`, `/students/me/notifications`, `/students/me/requests`
- `GET/POST /announcements`, `GET /approvals`, `POST /approvals/{id}/decide`
- `GET /reports/export` (CSV)
- `GET /health/face` (recognition engine status)

---

## Project layout

```
app/
  config.py            settings (security, enrollment, SMTP)
  database.py          SQLite schema, migrations, indexes, notifications
  services/
    face_service.py    InsightFace singleton (lazy, shared)
    rate_limit.py      in-memory sliding-window limiter
  routes/              auth, register, attendance, admin, students,
                       staff, announcements, notifications, approvals, reports
  main.py              app factory, CORS, rate-limit middleware, static serving
frontend/
  index.html           SPA shell (sidebar, topbar, router)
  login.html register.html forgot-password.html scanner.html
  assets/css/styles.css        enterprise design system
  assets/js/core.js            state, api, router, UI primitives
  assets/js/shared.js          attendance, announcements, profile, face, notifications, scanner, overview
  assets/js/admin.js           student management, approvals, audit, settings
```

---

## Security notes

- Set `JWT_SECRET_KEY` to a long random value before any production use.
- For production, set `CORS_ORIGINS` to your specific origin(s). A wildcard origin
  automatically disables credentialed CORS.
- Login is rate-limited per IP; OTP requests are gated (60s) and expire.
- All database access uses parameterized queries; passwords are bcrypt-hashed.
